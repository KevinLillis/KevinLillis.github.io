print("Enter n: ")
n = parse(UInt8, readline())
for a = 1:n, b = a:n, c = b:n
            if((a*a) + (b*b) == (c*c))
                println("$(a),$(b),$(c)")
    end
end
