playerScore = 0
dealScore = 0
pCard1 = rand(1:10)
pCard2 = rand(1:10)
dCard1 = rand(1:10)
dCard2 = rand(1:10)
pScore = pCard1 + pCard2
dScore = dCard1 + dCard2
playerFin = 0
dealerFin = 0
println("Your first two cards are: $(pCard1) and $(pCard2). With a total of $(pScore)")
println("The dealers first two cards are: $(dCard1) and one you cannot see.")
while playerFin == 0
    print("Do you wish to hit(0) or pass(1)?")
    n = parse(UInt8, readline())
    if n == 0
        newCard = rand(1:10)
        pScore = pScore + newCard
        println("Your new card is $(newCard) you are now at $(pScore).")
        if pScore > 21
            println("You bust, Dealer wins!")
            playerFin = 2
        end
    else
        playerFin = 1
    end
end

if playerFin == 1
    while dScore < 17
        newCard = rand(1:10)
        dScore = dScore + newCard
        println("The dealer's new card is $(newCard).")
        if dScore > 21
            println("Dealer bust, you win!")
            dealerFin = 2
        end
    end
end
if dealerFin == 2 || playerFin == 2
    println("Thanks for playing!")
else
    println("Final score:\n Player: $(pScore)\n Dealer: $(dScore)")
    if pScore > dScore
        println("You win!")
    else
        println("Dealer wins!")
    end
end
