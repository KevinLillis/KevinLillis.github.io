print "Enter a value for n: "
n = gets.to_i

1.upto(n) do |c| #loops from 1 to n
  1.upto(c) do |b|
    1.upto(b) do |a|
      puts "(#{a},#{b},#{c})" if a * a + b * b == c * c
    end
  end
end

