#prints 1 - 4
#start from 1, not 0
for i in (1..4)
    print i, ''
    print "\n"
end 
