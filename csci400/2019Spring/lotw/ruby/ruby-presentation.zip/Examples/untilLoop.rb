#Until loop, opposite of while loop

print "Enter x: "
x = gets.chomp.to_i #".chomp" avoids skip line

until x < 0
  puts x
  x -= 1 #subtracts 1 from x, until less than 0
end

puts "Done!"

