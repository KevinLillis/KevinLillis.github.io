#If statment, gets number from user and prints
#message depending on size 
print 'Enter n: '
x = gets.to_i #"gets" copies from user, ".to_i" converts string to integer
if x > 5
  print "I am big!"
elsif x == 5
  print "I am medium!"
else
  print "I am small!"
end

