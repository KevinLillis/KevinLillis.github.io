puts "It does not matter how slowly you go as long as you do not stop -Confucius"

