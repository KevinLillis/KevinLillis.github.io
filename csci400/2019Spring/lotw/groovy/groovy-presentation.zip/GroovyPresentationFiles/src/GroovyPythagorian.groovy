/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benjamin
 */
class GroovyPythagorian {
	public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter a value for n: ");
        def n = keyboard.nextInt();
        
        for (def a = 1; a <= n; a++) {
            for (def b = a + 1; b <= n; b++) {
                for (def c = b + 1; c <= n; c++) {
                    if (a * a + b * b == c * c) {
                        System.out.printf("%d, %d, %d%n", a, b, c);
                    }
                }
            }
        }

    }
}

