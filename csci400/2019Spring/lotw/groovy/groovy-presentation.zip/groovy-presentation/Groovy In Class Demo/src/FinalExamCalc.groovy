/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benjamin
 */
class FinalExamCalc {
	public static void main(String[] args){
            Scanner keyboard = new Scanner(System.in);
            
            System.out.print("Enter your total grade so far: ");
            def totalGrade = keyboard.nextInt();
            
            System.out.print("Enter the grade you wish to recieve: ");
            def wantedGrade = keyboard.nextInt();
            
            System.out.print("Enter the amount the final is worth: ")
            def finalWorth = keyboard.nextInt();
            
            finalWorth = finalWorth / 100;
            def finalCal;
            finalCal = 1 - finalWorth;
            finalCal = finalCal * totalGrade;
            finalCal = wantedGrade - finalCal;
            finalCal = finalCal / finalWorth;
            System.out.println("You will need to get a: " + finalCal);
            
        }
}

