//import 'package:Quote/Quote.dart' as Quote;

main(List<String> arguments) {
  print("Don't be boring\n\tHunter S. Thompson");
}
