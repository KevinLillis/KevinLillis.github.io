//import 'package:PythagoreanTriples/PythagoreanTriples.dart' as PythagoreanTriples;
import 'dart:io';
main(List<String> arguments){
  //print('Hello world: ${PythagoreanTriples.calculate()}!');

  print("Enter a value for n: ");
  var input = stdin.readLineSync();
  int n = int.parse(input);
  stdout.writeln("The pythagorean triples up to $n are:");

  for (int a = 1; a <= n; a++) {
    for (int b = a + 1; b <= n; b++) {
      for (int c = b + 1; c <= n; c++) {
        if (a * a + b * b == c * c) {
          print("$a, $b, $c");
        }
      }
    }
  }
}