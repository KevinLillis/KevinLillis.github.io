local n = io.read("*l")
local squares = {}
for i = 1, n do
	squares[i*i] = i
end
for a = 1, n-2 do
	for b = a+1, n-1 do
		local c = squares[a*a+b*b]
		if c then
			print(("%d, %d, %d"):format(a,b,c))
		end
	end
end
io.write("Press enter to quit...")
io.read("*l")