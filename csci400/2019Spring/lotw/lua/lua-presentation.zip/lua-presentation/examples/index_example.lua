local array_1 = {}

table.insert(array_1,"First value")
print(array_1[1])

local array_2 = {}
array_2[0] = "index 0"
array_2[1] = "index 1"
array_2[2] = "index 2"
print(#array_2) -- gets length of array_2, prints 2 since index 0 is ignored