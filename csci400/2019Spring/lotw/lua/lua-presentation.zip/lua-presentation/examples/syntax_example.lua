print("Scope example")
local a = 2
local b = 6
if a < b then
	print(a) -- 2
	b = 4
	local b = 16
end
print(b) -- 4

print("\n\nFunction example")

local function f_add(x,y)
	return x+y
end
print(f_add(4,7)) -- 11

print("\n\nWhile loop")

local i = 0
while i < 5 do
	print(i) -- 0,1,2,3,4
	i = i+1
end

print("\n\nFor loop")

for i = 0, 5 do
	print(i) -- 0,1,2,3,4,5
end

print("\n\nLoop over table as array")

local array = {"a",1,nil,"Hello","World"}
for i = 1, #array do
	print(array[i])
end

print("\n\nTable as map example")

local map = {hello="World",["test"]="123"}
map.hi = "abc"
print(map["hi"])
print(map["hello"])
print(map.test)
print(map["test"]) -- map["test"] and map.test are treated identically