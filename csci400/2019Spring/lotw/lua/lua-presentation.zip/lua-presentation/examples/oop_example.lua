local BankAccount = {}

local BankAccount_mt = {__index=BankAccount}
function BankAccount_mt:__tostring()
	return "Balance: "..tostring(self.balance)
end
function BankAccount:new(balance)
	return setmetatable({balance=balance or 0}, BankAccount_mt)
end
function BankAccount:deposit(x)
	self.balance = self.balance+x
end
function BankAccount:withdraw(x)
	self.balance = self.balance-x
end
function BankAccount:transferTo(account,x)
	self.balance = self.balance-x
	account.balance = account.balance+x
end


local account_1 = BankAccount:new()
print("Account 1",account_1) -- 0
account_1:deposit(50)
print("Account 1",account_1) -- 50

local account_2 = BankAccount:new(100)
print("Account 2",account_2) -- 100


account_2:transferTo(account_1,10)
print("Account 1",account_1) -- 60
print("Account 2",account_2) -- 90