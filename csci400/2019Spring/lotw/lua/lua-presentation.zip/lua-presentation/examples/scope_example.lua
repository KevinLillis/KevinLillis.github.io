local b = "Value b"
function function_1()
	return a,b -- only b is defined here since b was declared before this function
end
local a = "Value a"
print(function_1()) -- nil, Value b



local c = "Value c"
do
	print(c) -- Value c since we are below the declaration and in the same chunk
	
	local d = "Value d"
end
print(d) -- nil since we are outside the chunk d was declared in

local e
function function_2()
	return e
end
e = "Value e"
print(function_2()) -- Value e since e was declared before the function
