package main
import("fmt")

func main(){
	fmt.Print("\nDo or do not, there is no try - Master Yoda\n")
}