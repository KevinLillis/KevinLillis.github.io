package main
import("fmt")

func main(){
	fmt.Println("---------------------")
	var n int

	fmt.Print("Enter a value for n: ")

	_, err := fmt.Scanf("%d", &n)
		if err != nil{fmt.Println(err)}
	
	for a := 1; a <= n; a++{
		for b := a + 1; b <= n; b++{
			for c := b + 1; c <= n; c++{
				if (a*a + b*b) == (c*c){
					fmt.Println(a,b,c);
				}
			}
		}
	}
}