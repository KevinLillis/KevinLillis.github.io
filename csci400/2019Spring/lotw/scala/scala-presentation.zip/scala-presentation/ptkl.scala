/* 
    Pythagorean Triples written in Scala
    Author: Dr. Lillis
*/

object PythagoreanTriples {
    def main(args: Array[String]){
        val scanner = new java.util.Scanner(System.in)
        print("Enter a value for n: ")
  
        val n = scanner.nextLine().toInt
  
        for {
            a <- 1 to n
            b <- a+1 to n
            c <- b+1 to n
        } if (a*a + b*b == c*c) { 
            println("[" + a + ", " + b + ", "  + c + "]")
        }
     }
}