object Quote { 
  def main(args: Array[String]){
    println("The opposite of losing isn't not winning, it's quitting.")
  }
}