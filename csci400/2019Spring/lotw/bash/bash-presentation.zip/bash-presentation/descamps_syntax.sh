#!/bin/bash

# Other Useful Syntax Knowledge

# Comments
printf "\nStarting a line with # will make a comment"

printf "\n\nEnter the number to use with the examples: "
read something

# For
printf "\n---For Loop---"

for (( i=0; $i<=$something; i++ )); do
	printf "\n $i"
done

# If > Else > IF > Elseif
printf "\n\n---If > Else > IF > Elseif---"

if [[ $something -eq 12 ]]; then
	printf "\nThe number is equal to 10"
else
	if [[ $something -gt 10 ]]; then
		printf "\nThe number is greater then 10"
	elif [[ $something -lt 10 ]]; then
		printf "\nThe number is less then 10"
	fi
fi

# While
printf "\n\n---While loop---"

count=0
while [[ $count -lt $something ]]; do
	let "count++"
	printf "\n$count"
done

# Incrementing
printf "\n\n---Incrementing---"

copy=$something
printf "\nBefore: $copy"
let "copy++"
printf "\nAfter: $copy"

# Random Number
printf "\n\n---Generating a random number---"

random=$[($RANDOM % $something) +1]
printf "\nThis is a random number between 1 and $something: $random"

#How I did math
printf "\n\n---How I did math---"

somethingMath=$(( $something * $something + $something * $something ))
printf "\n$somethingMath\n\n"