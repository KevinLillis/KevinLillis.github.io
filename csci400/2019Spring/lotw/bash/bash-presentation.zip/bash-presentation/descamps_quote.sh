#!/bin/bash
# /mnt/c/users/capta/documents/school/'Year 3 - Spring 2019'/CSCI-400/Presentations/bash

# Brandon Descamps
# CSCI-400/
# Bash: Quote
# 2/9/2018

printf "\nIf I hadn't had music in my life, it's quite possible I'd be dead and I'd much rather be alive. - James Hetfield"