#!/bin/bash
# /mnt/c/users/capta/documents/school/Year 3 - Spring 2019/CSCI-400/Presentations/bash$

# Brandon Descamps
# CSCI-400/
# Bash: Pythagorean Triples
# 2/9/2018

printf "\nEnter in the number: "
read number

printf "\n"
for (( a=1; a<=number; a++ ))
do
	for (( b=a+1; b<=$number; b++ ))
	do
		for (( c=b+1; c<=$number; c++ ))
		do
			if [[ $(( $a * $a + $b * $b )) -eq $(( $c * $c )) ]]; then
				printf "$a, $b, $c\n"
			fi
		done
	done
done
printf "\n"
