use std::io; //Standard input/output library.

fn main() { //declare main function
	//String for user input
let mut input_n = String::new();	//let is our designator for variables. All rust variables are immutable by default, so we have
//to include the mut to indicate this variable isn't static.
    println!("Please enter an integer:"); //user prompt
	io::stdin().read_line(&mut input_n) //this is the std::io read line command
	.expect("Failed to read line."); //.expect returns an error if it doesn't read a line.
	let input_int: i32 = input_n.trim().parse() // the colon and i32 designate input_int as a 32-bit integer. input_n.trim() etc.
	//cast our string as an int
		.expect("Please type a number!"); //.expect gives an error if an i32 value is not returned.
	println!("You entered: {}", input_int);
	//curly braces {} indicate spaces to put variables into, similar to printf in Java.
	//This returns the input value to confirm it.
	pythagoras(input_int);
}

//This function will calculate all integer combinations that form pythagorean triples
//Up to, and including, the user-defined N value.
fn pythagoras(n:i32){
	println!("All Pythagorean triples with hypotenuse less than c = {}",n);
	
	for side_a in 1..n+1{
		for side_b in side_a+1..n+1{
			for side_c in side_b+1..n+1{
				if side_a*side_a + side_b*side_b == side_c*side_c{
					println!("{},{},{}", side_a,side_b,side_c);
				}
			}
		}
	}
}

