fn main() {
    println!("If you meet the Buddha on the road, kill the Buddha");
	println!("--Zen Koan");
}
