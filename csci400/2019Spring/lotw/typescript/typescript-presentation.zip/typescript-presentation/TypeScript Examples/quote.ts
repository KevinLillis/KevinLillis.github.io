var message:string = "'Muddy water is best cleared by leaving it alone.' -Alan Watts.";
document.body.innerHTML = message;