function PythagoreanTriples() {
	var n:number = parseFloat((<HTMLInputElement>document.getElementById("myInput")).value);
	
	for(var a:number = 1; a <= n; a++){
		for(var b:number = a + 1; b <= n; b++){
			for (var c:number = b + 1; c <= n; c++){
				if(a * a + b * b == c * c){
					document.getElementById("output").innerHTML += a + "," + b + "," + c + "<br>";
					
				}
			}
		}
	}
}