function PythagoreanTriples() {
    var n = parseFloat(document.getElementById("myInput").value);
    for (var a = 1; a <= n; a++) {
        for (var b = a + 1; b <= n; b++) {
            for (var c = b + 1; c <= n; c++) {
                if (a * a + b * b == c * c) {
                    document.getElementById("output").innerHTML += a + "," + b + "," + c + "<br>";
                }
            }
        }
    }
}
