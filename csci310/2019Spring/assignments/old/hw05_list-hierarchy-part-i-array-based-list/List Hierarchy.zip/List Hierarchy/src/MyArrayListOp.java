
/**
 * An optimized array-based list. Overrides methods of MyAbstractList.
 * @author Dr. Lillis
 * @param <E> type of elements stored in this list.
 */
public class MyArrayListOp<E> extends MyArrayList<E> {
     
    /**
     * Constructs an empty array-based list with capacity set to the 
     * INITIAL_CAPACITY.
     */
    public MyArrayListOp(){
        super();
    }
    
    /**
     * Constructs an array-based list containing the elements in the specified
     * array. If the array argument is non-empty, the capacity of this 
     * list is set to the list's size. However, if the array argument is empty,
     * the capacity of this list is set to the INITIAL_CAPACITY.
     * @param eArr array containing initial list elements
     */
    public MyArrayListOp(E[] eArr){
        super(eArr);
    }     
    
    @Override
    public E removeLast(){
        if(isEmpty()){
            throw new IllegalStateException("List is empty, cannot remove last.");
        }
        size--;
        return arr[size];
    }
        
    @Override
    public void clear(){
        arr = (E[])new Object[capacity()];
        size = 0;
    }

}
