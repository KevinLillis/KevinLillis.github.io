/**
 * Array based list. Implements those methods not implemented in MyAbstractList.
 * @author Dr. Lillis
 * @param <E> type of elements stored in this list
 */
public class MyArrayList<E> extends MyAbstractList<E> {
    /**
     * Initial capacity of this list.
     */
    public static final int INITIAL_CAPACITY = 4;
    
    /**
     * Array to hold the list elements.
     */
    protected E[] arr = (E[])new Object[INITIAL_CAPACITY];
    
    /**
     * Constructs an empty array-based list with capacity set to the 
     * INITIAL_CAPACITY.
     */
    public MyArrayList(){
        
    }
    
    /**
     * Constructs an array-based list containing the elements in the specified
     * array. If the array argument is non-empty, the capacity of this 
     * list is set to the list's size. However, if the array argument is empty,
     * the capacity of this list is set to the INITIAL_CAPACITY.
     * @param eArr array containing initial list elements
     */
    public MyArrayList(E[] eArr){
        for(E e : eArr){
            add(e);
        }
        if(eArr.length > 0){
            trimToSize();
        }
    }
    
    /**
     * Returns the capacity of this list.
     * @return capacity of this list
     */
    public int capacity(){
        return arr.length;
    }
    
    /**
     * Increases the capacity of this ArrayList instance, if necessary, to 
     * ensure that it can hold at least the number of elements specified by the 
     * minimum capacity argument.
     * @param newCap the desired minimum capacity
     * @throws IllegalArgumentException if specified capacity is &le; 0
     */
    public void ensureCapacity(int newCap){
        if(newCap <= 0){
            throw new IllegalArgumentException("Capacity must be positive");
        }
        if(newCap > capacity()){
            int newCapacity = newCap;
            E[] bigArr = (E[])new Object[newCapacity];
            System.arraycopy(arr, 0, bigArr, 0, size);
            arr = bigArr;
        }
    }
    
    /**
     * Trims the capacity of this list to be the list's current size.
     */
    public void trimToSize(){
        E[] smaller = (E[])new Object[size];
        System.arraycopy(arr, 0, smaller, 0, size);
        arr = smaller;
    }
    
    @Override
    public E get(int i) throws IndexOutOfBoundsException {
        if(i < 0 || i >= size){
            throw new IndexOutOfBoundsException("Cannot get element " + i);
        }
        
        return arr[i];
    }
    
    @Override
    public void add(int i, E e) throws IndexOutOfBoundsException {
        if(i < 0 || i > size){
            throw new IndexOutOfBoundsException("Cannot add element " + i);
        }
        
        if(size == capacity()){
            // double size of array
            int newCapacity = 2 * capacity();
            E[] bigArr = (E[])new Object[newCapacity];
            System.arraycopy(arr, 0, bigArr, 0, size);
            arr = bigArr;
        }
        
        // Shift elements to right to make room for new element at position i
        System.arraycopy(arr, i, arr, i+1, size - i);
        arr[i] = e;
        size++;
    }
        
    @Override
    public E remove(int i) throws IndexOutOfBoundsException {
        if(i < 0 || i >= size){
            throw new IndexOutOfBoundsException("Cannot remove element " + i);
        }
        E e = arr[i];
        System.arraycopy(arr, i+1, arr, i, size - i - 1);
        size--;
        
        return e;
    }
    
    @Override
    public int firstIndexOf(E e){
        for(int i = 0; i < size; i++){
            if(arr[i].equals(e)){
                return i;
            }
        }
        return -1;
    }

    @Override
    public int lastIndexOf(E e){
        for(int i = size-1; i >=0 ; i--){
            if(arr[i].equals(e)){
                return i;
            }
        }
        return -1;
    }
    
    @Override
    public E set(int i, E e){
        if(i < 0 || i >= size){
            throw new IndexOutOfBoundsException("Cannot set element " + i);
        }
        
        E temp = arr[i];
        arr[i] = e;
        return temp;
    }    
}
