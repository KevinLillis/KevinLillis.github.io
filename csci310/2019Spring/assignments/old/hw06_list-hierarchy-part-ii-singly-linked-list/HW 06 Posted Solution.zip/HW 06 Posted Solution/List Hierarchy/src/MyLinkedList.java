/**
 * Singly linked list. Implements those methods not implemented 
 * in MyAbstractList.
 * @author Dr. Lillis
 * @param <E> type of elements stored in this list
 */
public class MyLinkedList<E> extends MyAbstractList<E> {
    /**
     * Reference to the first element in this list. Null if the list is empty.
     */
    protected SNode<E> head = null;

    /**
     * Reference to the last element in this list. Null if the list is empty.
     */
    protected SNode<E> tail = null;

    /**
     * Constructs and empty list.
     */
    public MyLinkedList() {
        super();
    }

    /**
     * Constructs a new list containing the elements in the array parameter.
     * @param eArr array containing initial list elements
     */
    public MyLinkedList(E[] eArr) {
        for (E e : eArr) {
            add(e);
        }
    }

    @Override
    public E get(int i) throws IndexOutOfBoundsException {
        if (i < 0 || i >= size) {
            throw new IndexOutOfBoundsException("Cannot get element " + i);
        }
        
        E temp;
        if(i == 0){
            temp = head.e;
        } else if(i == size - 1){
            temp = tail.e;
        } else {
            SNode<E> current = move(i);
            temp = current.e;
        }
        return temp;
        
    }

    @Override
    public void add(int i, E e) throws IndexOutOfBoundsException {
        if (i < 0 || i > size) {
            throw new IndexOutOfBoundsException("Cannot add element " + i);
        }
        SNode<E> insert = new SNode<>(e);
        if (isEmpty()) {
            head = tail = insert;
        } else if (i == 0) {
            insert.next = head;
            head = insert;
        } else if (i == size) {
            tail.next = insert;
            tail = insert;
        } else {
            SNode<E> current = move(i - 1);
            insert.next = current.next;
            current.next = insert;
        }
        size++;
    }


    @Override
    public E remove(int i) throws IndexOutOfBoundsException {
        if (i < 0 || i >= size) {
            throw new IndexOutOfBoundsException("Cannot remove element " + i);
        }
        E temp;

        if (size == 1) {
            temp = head.e;
            head = tail = null;
        } else if (i == 0) {
            temp = head.e;
            SNode<E> oldHead = head;
            head = head.next;
            oldHead.next = null;
        } else if (i == size - 1){
            temp = tail.e;
            SNode<E> previous = null;
            SNode<E> current = head;

            for (int j = 0; j < i; j++) {
                previous = current;
                current = current.next;
            }

            tail = previous;
            tail.next = null;
        } else {
            SNode<E> previous = null;
            SNode<E> current = head;

            for (int j = 0; j < i; j++) {
                previous = current;
                current = current.next;
            }

            temp = current.e;
            previous.next = current.next;
            current.next = null;
        }

        size--;
        return temp;
    }

    @Override
    public E set(int i, E e) throws IndexOutOfBoundsException {
        if (i < 0 || i >= size) {
            throw new IndexOutOfBoundsException("Cannot set element " + i);
        }
        
        E temp;
        if(i == 0){
            temp = head.e;
            head.e = e;
        } else if(i == size - 1){
            temp = tail.e;
            tail.e = e;
        } else {
            SNode<E> current = move(i);
            temp = current.e;
            current.e = e;
        }
        return temp;
    }


    @Override
    public int firstIndexOf(E e) {
        SNode<E> current = head;
        for (int i = 0; i < size; i++) {
            if (e.equals(current.e)) {
                return i;
            }
            current = current.next;
        }
        return -1;
    }

    @Override
    public int lastIndexOf(E e) {
        int foundAt = -1;

        SNode<E> current = head;
        for (int i = 0; i < size; i++) {
            if (e.equals(current.e)) {
                foundAt = i;
            }
            current = current.next;
        }
        return foundAt;
    }


    /* Starts at head and moves forward i positions */
    private SNode<E> move(int i) {
        SNode<E> current = head;
        for (int j = 0; j < i; j++) {
            current = current.next;
        }
        return current;
    }
}
