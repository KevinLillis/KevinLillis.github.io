/**
 * An optimized doubly linked list. Overrides methods of MyAbstractList.
 * @author Dr. Lillis
 * @param <E> type of elements stored in this list.
 */
public class MyLinkedListOp<E> extends MyLinkedList<E> {

    /**
     * Constructs an empty list.
     */
    public MyLinkedListOp() {
        super();
    }

    /**
     * Constructs a list containing the elements of the array parameter.
     * @param eArr array containing initial list elements
     */
    public MyLinkedListOp(E[] eArr) {
        super(eArr);
    }

    @Override
    public void clear() {
        head = tail = null;
        size = 0;
    }

    @Override
    public String toString() {
        String s = "[";
        SNode<E> current = head;
        boolean first = true;
        while (current != null) {
            if (first) {
                s += current.e.toString();
                first = false;
            } else {
                s += ", " + current.e.toString();
            }

            current = current.next;
        }

        s += "]";
        return s;
    }
}
