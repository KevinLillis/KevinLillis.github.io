/**
 * Node for a singly linked list.
 * @author Dr. Lillis
 * @param <E> type of elements to store in the list.
 */
public class SNode<E> {

    /**
     * Data element stored in this node
     */
    protected E e;

    
    /**
     * Reference to the next node in this singly linked list.
     */
    protected SNode<E> next;

    /**
     * Constructs a new node containing the specified data item.
     * @param e element stored in this node
     */
    protected SNode(E e) {
        this.e = e;
    }
}